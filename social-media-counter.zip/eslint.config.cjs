const { FlatCompat } = require('@eslint/eslintrc');
const compat = new FlatCompat();
module.exports = [
  ...compat.config(require('./.eslintrc.cjs')),
  {
    ignores: [
      'node_modules/**',
      'build/**',
      'public/build/**',
      'shopify-app-remix/**',
      '*/*.yml',
      '.shopify/**',
    ],
  },
];
