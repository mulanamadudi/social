export { loader, action } from "./admin.socials";
export { default } from "./admin.socials";
